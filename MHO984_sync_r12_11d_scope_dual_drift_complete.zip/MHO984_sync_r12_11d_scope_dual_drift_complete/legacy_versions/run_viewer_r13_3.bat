@echo off
setlocal
cd /d "%~dp0"

echo MHO984 Viewer r13.3 - Auto frequency/period/duty + edge delay + cursor keyboard fix
echo Viewer only - no waveform acquisition is performed.
echo.
python -u viewer_mho984_r13_3_auto_measure.py %*
set EXITCODE=%ERRORLEVEL%
if not "%EXITCODE%"=="0" (
  echo.
  echo Viewer ended with an error.
  pause
)
endlocal
exit /b %EXITCODE%
