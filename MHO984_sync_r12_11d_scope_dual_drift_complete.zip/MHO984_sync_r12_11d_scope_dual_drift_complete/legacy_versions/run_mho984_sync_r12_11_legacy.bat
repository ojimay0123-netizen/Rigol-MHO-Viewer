@echo off
setlocal
cd /d "%~dp0"
python -u mho984_sync_r12_11_gui_settings.py --legacy-defaults %*
set EXITCODE=%ERRORLEVEL%
if not "%EXITCODE%"=="0" (
  echo.
  echo MHO984 Sync r12.11 legacy mode ended with an error.
  pause
)
endlocal
exit /b %EXITCODE%
