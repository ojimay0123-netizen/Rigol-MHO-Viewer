@echo off
setlocal
cd /d "%~dp0"

echo ============================================================================
echo MHO984 Sync r12.11a - Stable RG03 BIN
echo ============================================================================
echo Program folder: %CD%
echo Starting Python and opening the settings GUI...
echo If the GUI is not visible, check the taskbar for "MHO984 取得設定".
echo.

python -u mho984_sync_r12_11_gui_settings.py %*
set EXITCODE=%ERRORLEVEL%

echo.
echo Python process ended. Exit code: %EXITCODE%

if not "%EXITCODE%"=="0" (
  echo.
  echo MHO984 Sync r12.11a ended with an error.
  pause
)

endlocal
exit /b %EXITCODE%
