@echo off
setlocal
cd /d "%~dp0"
echo ============================================================================
echo MHO984 r12.11a - Re-decode existing dataset (LA low16 fix)
echo ============================================================================
echo Select an existing mho984_* dataset. No new oscilloscope acquisition is done.
echo.
python -u redecode_existing_dataset_r12_11.py %*
set EXITCODE=%ERRORLEVEL%
if not "%EXITCODE%"=="0" (
  echo.
  echo Re-decode ended with an error.
  pause
) else (
  echo.
  echo Re-decode completed successfully.
  pause
)
endlocal
exit /b %EXITCODE%
