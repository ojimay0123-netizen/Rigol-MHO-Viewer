MHO984 Sync r12.11c / Viewer r13.3
=================================

Base
----
This package is based on r12.11b. The acquisition, FTP retrieval, RG03 BIN
parsing, and the verified LA lower16 / stride-2 decoding are retained.

Main launchers
--------------
00_START_MHO984_r12_11c.bat
    Recommended one-click launcher.

run_mho984_sync_r12_11c.bat
    Settings GUI -> acquisition -> decode -> Viewer r13.3.

run_viewer_r13_3.bat
    Viewer only. No acquisition is performed.

redecode_existing_dataset_r12_11b.bat
    Re-decode Digital from an existing dataset without rewriting Analog.

Viewer r13.3 changes
--------------------
1. Automatic Digital measurements
   - Frequency
   - Period
   - High pulse width
   - Low pulse width
   - Duty cycle
   - Rising / Falling edge counts
   - Period standard deviation

   Measurements are calculated without A/B cursors for Digital channels
   currently selected in the left channel list.

2. Automatic Analog <-> Digital edge delay summary
   - Uses settings in the "同期確認" tab:
       Analog / Digital / Threshold / Slope / Pair tolerance
   - Reports Digital edge - Analog threshold crossing
   - Mean / Median / Std.dev / Min / Max
   - Recomputed automatically after dataset/channel selection and when the
     Analog/Digital/Slope selector is changed.
   - The "再測定" button can be used at any time after changing Threshold or
     Tolerance values.

3. Cursor C-Z keyboard fix
   - A-Z keys select an existing cursor directly.
   - Left / Right moves the selected cursor by 1 sample.
   - Shift + Left / Right moves it by 10 samples.
   - After selecting a cursor from the combo box or adding a cursor, keyboard
     focus automatically returns to the waveform canvas.
   - C/R/Z legacy actions are used only when the corresponding cursor does not
     exist. Once cursor C/R/Z exists, the letter selects that cursor.
   - Cursor positions can always be cleared with the "位置クリア" button.

Verified decoder policy retained from r12.11b
---------------------------------------------
For the observed MHO984 large-record LA layout:
  uint32 lower16 = D0-D15 waveform sample
  uint32 upper16 = ignored non-waveform field
  effective Digital interval = 2 * RG03 header x_increment

This is the decoding policy that removed the false high-speed toggling and
matched the 10 MHz / 12 MHz screen comparison.

Recommended use
---------------
1. Extract ZIP to a normal local folder such as C:\Temp\MHO984_sync_r12_11c...
2. Run 00_START_MHO984_r12_11c.bat
3. Capture or open an existing dataset.
4. Select D0/D8 etc. on the left.
5. Open "自動測定" for frequency / period / duty.
6. For edge delay, set the pair in "同期確認". The same settings are summarized
   automatically in "自動測定".

Python packages
---------------
Use install_python_packages.bat when NumPy / Matplotlib are not installed.
