MHO984 Sync r12.11a - Windows re-decode hotfix
==================================================

MHO984 Sync r12.11 - Stable RG03 BIN + Viewer r13.2
====================================================

この版について
--------------
このZIPは、ユーザー提供の「MHO984_sync_r12_9b_GUI_foreground_fix_complete」
を基準にした安定版アップデートです。

取得方式は変更していません。

  SINGLE -> STOP
  -> MHO984のC:/へRG03 Memory BINを1本保存
  -> anonymous FTPでPCへ1回転送
  -> 同じBINからCH1-CH4 + D0-D15をPC側でデコード
  -> Viewer起動

UltraSigma/VISAは使用しません。

重要: 前回の別方式（Parallel BUSイベントを直接SCPI取得する方式）には
切り替えていません。動作していたr12.9bの取得スタックを維持しています。

最新版の主な変更
----------------
1. r12.9bの設定GUI前面表示修正を維持
2. R12.7 RG03 BIN-only acquisition coreを維持
3. R12.7 stable-size FTP retrieverを維持
4. R12.7 Memory BIN decoderを維持
5. Viewerをr13.2へ更新
6. Viewerは以下の3形式を同時サポート
   - digital/digital_events.bin
     <float64 time_s, uint16 bus_value> little endian
   - digital_events.csv / digital/digital_events.csv
   - 従来の d0.bin～d15.bin + dN_pre.txt
7. CSVデジタル値の解釈を強化
   優先順位:
     D0-D15個別列 -> data_hex -> data_decimal
   "0100"を10進100 (=0x0064) と誤解釈せず、HEX 0x0100として扱えます。
8. Viewer-only BATを追加
9. Pythonパッケージ導入用BATを追加

通常起動
--------
  run_mho984_sync_r12_11.bat

設定GUIだけ確認
----------------
波形取得を行わず設定画面だけ確認します。

  test_mho984_settings_gui_r12_11.bat

GUIを使用しない従来動作
------------------------
  run_mho984_sync_r12_11_legacy.bat

または
  run_mho984_sync_r12_11.bat --no-gui

Viewerだけ起動
--------------
  run_viewer_r13_2.bat

データセットを直接指定することもできます。

  run_viewer_r13_2.bat C:\Temp\mho984_0001

必要パッケージ
--------------
Python 3 + NumPy + Matplotlib + Tkinter が必要です。
NumPy/Matplotlibは以下で導入できます。

  install_python_packages.bat

Tkinterは通常のWindows版Pythonに含まれます。

設定保存
--------
  %USERPROFILE%\.mho984_sync_settings.json

保存内容:
  scope_ip
  base_dir

標準初期値
----------
  Scope IP : 192.168.100.9
  SCPI port: 5555
  Base dir : C:\Temp

主要ファイル
------------
  mho984_sync_r12_11_gui_settings.py
      One-Click制御 + 設定GUI

  capture_mho984_sync_r12_7_bin_only_core.py
      SINGLE/STOP + MHO984 C:/へのRG03 Memory BIN保存

  mho984_lan_bin_retriever_r12_7_stable_ftp.py
      FTP SIZE安定待ち + anonymous FTP取得

  mho984_bin_decoder_r12_7.py
      RG03 Memory BINをCH1-CH4 + D0-D15へデコード

  viewer_mho984_r13_2_digital_compat.py
      4K対応Viewer + デジタル3形式互換

検証
----
配布前に全Pythonファイルへ py_compile を実行しています。
Viewerについて以下の合成データテストも実行しています。

  - D0-D15個別列を含むCSV
  - 0x prefix無しのHEX文字列 "0100"
  - digital_events.bin (<f8,u2>)
  - 従来 d0.bin + d0_pre.txt の検出

テスト結果は MHO984_sync_r12_11_test_report.json を参照してください。

注意
----
実機固有のファームウェア差やLAN/FTP状態はPC上の構文テストだけでは
完全には再現できません。取得に失敗した場合は、生成された
lan_retrieval_r12.json / capture_error.json / acquisition.json 等を残したまま
確認するのが安全です。


===============================================================================
重要: r12.11 Digital LA 修正 (2026-08-29)
===============================================================================

実機画面との比較で、MHO984 の large-record RG03 LA payload を
「uint32 low16 / high16 の2連続サンプル」と解釈すると、D1-D7 等の
本来静止しているチャンネルに高速な偽トグルが発生することが判明しました。

r12.11 では large-record signature:
  LA type=5, bytes_per_point=4, declared_data_bytes = actual payload * 2
に対して次の解釈へ修正しています。

  uint32 lower16 : D0-D15 の有効サンプル
  uint32 upper16 : 波形サンプルとして使用しない
  有効時間間隔  : RG03 header x_increment の 2 倍

これにより、upper16 を誤って時系列へ挿入して発生していた偽デジタル波形を
除去しつつ、Analog と Digital の全取得時間幅を一致させます。

既に取得済みの dataset は、元の memory/*.bin が残っていれば
  redecode_existing_dataset_r12_11.bat
で再取得せず Digital を再デコードできます。


===============================================================================
r12.11a hotfix: Re-decode OSError [Errno 22]
===============================================================================

症状:
  np.asarray(...).tofile(Path(...)) が Windows 環境で
  OSError: [Errno 22] Invalid argument を返し、analog/chan1.bin の再書込みで停止。

修正:
  1. 既存データの再デコードは Digital のみ更新し、analog/chan*.bin を一切書き換えない。
  2. NumPy ndarray.tofile(Path) を使わず、Path.open('wb') + ndarray.tobytes() で保存。
  3. 新規取得時の Analog/Digital BIN保存にも同じWindows-safe writerを使用。

既存データ修復:
  redecode_existing_dataset_r12_11.bat

この処理ではオシロから再取得せず memory/*.bin を再解析します。
Analogファイルはそのまま残し、Digital関連ファイルだけ更新します。

===============================================================================
r12.11b Windows lock-safe re-decode hotfix
===============================================================================
Symptom fixed:
  OSError: [Errno 22] Invalid argument:
  ...\digital\digital_events.bin

Cause:
  The Viewer reads digital event BIN files with NumPy memory mapping. On Windows,
  an open/memory-mapped digital_events.bin may not be safely truncated/overwritten.

Fix:
  - Re-decode never overwrites the previous digital_events.bin or digital_bus.bin.
  - It writes new versioned files such as:
      digital_events_redecode_YYYYMMDD_HHMMSS_mmm.bin
      digital_bus_redecode_YYYYMMDD_HHMMSS_mmm.bin
  - acquisition.json is updated to point to the new files.
  - Viewer r13.2a also finds the newest versioned event file as a fallback.
  - Analog files are still NOT rewritten during re-decode.

Use:
  1. Run redecode_existing_dataset_r12_11b.bat.
  2. Select the existing mho984_* dataset.
  3. After success, close/reopen that dataset in the Viewer.
