@echo off
setlocal
cd /d "%~dp0"

echo ============================================================================
echo MHO984 Sync r12.11c - Recommended launcher
echo r12.11b acquisition/decode base + Viewer r13.3 auto measurement/cursor fix
echo ============================================================================
echo.
call run_mho984_sync_r12_11c.bat %*
exit /b %ERRORLEVEL%
