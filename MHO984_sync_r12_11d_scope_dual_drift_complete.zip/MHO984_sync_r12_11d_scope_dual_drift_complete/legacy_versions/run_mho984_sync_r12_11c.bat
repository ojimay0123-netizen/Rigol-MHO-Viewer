@echo off
setlocal
cd /d "%~dp0"

echo ============================================================================
echo MHO984 Sync r12.11c - r12.11b base + auto measurement + cursor keyboard fix
echo ============================================================================
echo Program folder: %CD%
echo Starting Python and opening the settings GUI...
echo.

python -u mho984_sync_r12_11c_gui_settings.py %*
set EXITCODE=%ERRORLEVEL%

echo.
echo Python process ended. Exit code: %EXITCODE%
if not "%EXITCODE%"=="0" pause
endlocal
exit /b %EXITCODE%
