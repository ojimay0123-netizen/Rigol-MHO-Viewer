@echo off
setlocal
cd /d "%~dp0"

echo MHO984 settings GUI test r12.11
echo This test does NOT acquire waveform data.
echo.

python -u mho984_sync_r12_11_gui_settings.py --gui-test
set EXITCODE=%ERRORLEVEL%

echo.
echo GUI test ended. Exit code: %EXITCODE%
pause
exit /b %EXITCODE%
