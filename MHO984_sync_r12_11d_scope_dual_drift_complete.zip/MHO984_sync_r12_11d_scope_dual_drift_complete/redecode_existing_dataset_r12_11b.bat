@echo off
setlocal
cd /d "%~dp0"
echo ============================================================================
echo MHO984 r12.11b - Re-decode existing dataset (LA low16 + Windows lock fix)
echo ============================================================================
echo Select an existing mho984_* dataset. No new oscilloscope acquisition is done.
echo.
echo NOTE: This version writes NEW versioned digital BIN files, so it can work even
echo       when an older digital_events.bin is still memory-mapped by the Viewer.
echo.
python -u redecode_existing_dataset_r12_11b.py %*
set EXITCODE=%ERRORLEVEL%
if not "%EXITCODE%"=="0" (
  echo.
  echo Re-decode ended with an error.
  pause
) else (
  echo.
  echo Re-decode completed successfully.
  echo Close and reopen the dataset in Viewer so it reads the new manifest/file.
  pause
)
endlocal
exit /b %EXITCODE%
