@echo off
setlocal
cd /d "%~dp0"

echo Installing/updating packages required by MHO984 Sync...
python -m pip install --upgrade numpy matplotlib
set EXITCODE=%ERRORLEVEL%

echo.
if "%EXITCODE%"=="0" (
  echo Package installation completed.
) else (
  echo Package installation failed. Check Python/pip installation.
)
pause
exit /b %EXITCODE%
