@echo off
setlocal
cd /d "%~dp0"

echo ============================================================================
echo MHO984 r12.11d - Re-decode existing dataset (Digital only, lock-safe)
echo Uses the verified r12.11b lower16 / stride-2 re-decode path.
echo ============================================================================
echo.
python -u redecode_existing_dataset_r12_11b.py %*
set EXITCODE=%ERRORLEVEL%
if not "%EXITCODE%"=="0" pause
endlocal
exit /b %EXITCODE%
