@echo off
setlocal
cd /d "%~dp0"

echo ============================================================================
echo MHO984 Sync r12.11d - Recommended launcher
echo r12.11c base + Viewer r13.4 scope / dual edge delay / drift ppm
echo ============================================================================
echo.
call run_mho984_sync_r12_11d.bat %*
exit /b %ERRORLEVEL%
