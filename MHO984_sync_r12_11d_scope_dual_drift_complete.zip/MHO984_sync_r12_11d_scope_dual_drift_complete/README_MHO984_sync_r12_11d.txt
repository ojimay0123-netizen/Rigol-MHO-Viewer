MHO984 Sync r12.11d / Viewer r13.4
=================================

Base
----
This package is based directly on r12.11c. Acquisition, FTP retrieval,
RG03 parsing, and the verified LA lower16 / stride-2 decoding are unchanged.
The changes are concentrated in Viewer r13.4.

Recommended launcher
--------------------
00_START_MHO984_r12_11d.bat

Viewer only
-----------
run_viewer_r13_4.bat

Viewer r13.4 changes
--------------------
1. Selectable automatic-measurement scope
   - 全範囲
   - 表示範囲
   - A-B間

   The same selected scope is applied to:
   - Digital frequency / period / High width / Low width / Duty
   - Automatic Analog-Digital edge-delay analysis

   表示範囲 is automatically recalculated after zoom/pan.
   A-B間 is automatically recalculated after A/B placement or movement.

2. Two verified pairs displayed simultaneously
   - CH1 <-> D8
   - CH2 <-> D0

   These fixed-pair summaries use:
   - Threshold = Auto independently for each Analog channel
   - Slope = Rising
   - Pair tolerance = the value in the 同期確認 tab

   The manually selected pair from the 同期確認 tab is also retained below
   the two fixed pairs for backward compatibility.

3. Time drift in ppm
   For paired edges:
       delta_t = Digital edge - Analog threshold crossing
       drift_ppm = d(delta_t) / d(time) * 1e6

   Positive ppm means Digital becomes later relative to Analog toward the end
   of the selected range. The Viewer also reports fitted delay change across
   the analyzed span and R^2.

   Drift quality is marked GOOD only when the selected range is long enough
   and the regression is sufficiently supported. Very short displayed ranges
   still show a reference value, but it is marked REFERENCE because 1 ns LA
   timing quantization dominates ppm estimation over short spans.

4. Digital frequency/Duty quantization correction
   The effective LA interval is 1 ns in the verified 2 GSa/s / stride-2 data.
   For 12 MHz, individual measured periods therefore alternate around 83/84 ns.
   r13.4 uses the mean of many complete periods instead of the median, avoiding
   the false 12.048 MHz result that a median 83 ns period would produce.
   Duty uses the aggregate High-time / Period-time ratio for the same reason.

5. Lower-memory synchronization analysis
   Analog threshold crossing detection is processed in chunks. The Viewer no
   longer expands an entire 25 Mpts Analog channel into one float64 array merely
   to run synchronization analysis.

6. Cursor keyboard fix retained from r13.3
   - A-Z selects an existing cursor.
   - Left/Right = 1 sample.
   - Shift+Left/Right = 10 samples.
   - C and later cursors remain keyboard-operable.

Verified decoder policy retained
--------------------------------
For the observed MHO984 large-record LA layout:
  uint32 lower16 = D0-D15 waveform sample
  uint32 upper16 = ignored non-waveform field
  effective Digital interval = 2 * RG03 header x_increment

Existing dataset re-decode
--------------------------
redecode_existing_dataset_r12_11d.bat
uses the verified r12.11b lock-safe implementation internally and does not rewrite Analog data.

Recommended use
---------------
1. Extract the ZIP to a normal local folder, for example C:\Temp\MHO984_r12_11d
2. Run 00_START_MHO984_r12_11d.bat
3. Capture or open a dataset.
4. Open 自動測定.
5. Select 全範囲 / 表示範囲 / A-B間.
6. Check CH1<->D8 and CH2<->D0 together.
7. Use 全範囲 or a millisecond-class range when ppm drift accuracy matters.

Legacy files
------------
Older r12.11/r12.11b/r12.11c launchers and Viewer r13.2/r13.3 are stored in
legacy_versions for rollback/reference. Use the r12.11d / r13.4 files at the
top level for normal operation.
