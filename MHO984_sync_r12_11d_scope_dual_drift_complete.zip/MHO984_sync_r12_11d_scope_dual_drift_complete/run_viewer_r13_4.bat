@echo off
setlocal
cd /d "%~dp0"

echo ============================================================================
echo MHO984 Viewer r13.4 - scope / dual edge delay / drift ppm
echo ============================================================================
echo.
python -u viewer_mho984_r13_4_scope_dual_drift.py %*
set EXITCODE=%ERRORLEVEL%
if not "%EXITCODE%"=="0" pause
endlocal
exit /b %EXITCODE%
